//! The [system native program][np].
//!
//! [np]: https://docs.trezoa.io/runtime/programs#system-program

crate::declare_id!("11111111111111111111111111111111");
