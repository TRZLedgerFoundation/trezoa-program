//! The [ed25519 native program][np].
//!
//! [np]: https://docs.trezoa.io/runtime/programs#ed25519-program

crate::declare_id!("Ed25519SigVerify111111111111111111111111111");
