#[deprecated(
    since = "1.11.0",
    note = "please use `trezoa_program::stake::tools::get_minimum_delegation()` instead"
)]
pub const MINIMUM_STAKE_DELEGATION: u64 = 1;
